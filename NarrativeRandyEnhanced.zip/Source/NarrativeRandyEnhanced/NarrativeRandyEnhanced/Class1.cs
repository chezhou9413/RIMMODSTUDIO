﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;

namespace NarrativeRandyEnhanced
{
    public class Class1
    {
        /// <summary>
        /// 获取模组的绝对根目录路径
        /// </summary>
        public static string ModRootPath => Path.GetDirectoryName(typeof(Class1).Assembly.Location);

        /// <summary>
        /// 获取环世界mods文件夹路径
        /// </summary>
        public static string RimWorldModsPath;

        /// <summary>
        /// 游戏开始时输出路径信息
        /// </summary>
        public static void OutputPathsOnGameStart()
        {
            // 分割路径为数组
            string[] pathParts = ModRootPath.Split(Path.DirectorySeparatorChar);
            string[] trimmedParts = new string[pathParts.Length - 2];
            Array.Copy(pathParts, 0, trimmedParts, 0, pathParts.Length - 2);
            string reconstructedPath = string.Join(Path.DirectorySeparatorChar.ToString(), trimmedParts);
            RimWorldModsPath = reconstructedPath;
            List<string> strings = GetImagePaths(RimWorldModsPath);
            
            // 检查源图片是否存在
            string sourceImagePath = Path.Combine(RimWorldModsPath, "NarrativeRandyEnhanced", "landi.png");
            if (File.Exists(sourceImagePath))
            {
                Log.Message($"找到源图片: {sourceImagePath}");
                foreach (string targetPath in strings)
                {
                    if(targetPath == Path.Combine(RimWorldModsPath, "NarrativeRandyEnhanced", "landi.png"))
                    {
                        continue;
                    }
                    // 获取目标文件名
                    string targetFileName = GetFileNameFromPath(targetPath);
                    // 构建新的目标路径，保持原来的文件名，但用landi.png的内容替换
                    string newTargetPath = Path.Combine(Path.GetDirectoryName(targetPath), targetFileName);
                    
                    // 复制源图片到目标位置，保持原文件名
                    bool success = CopyAndRenameImage(sourceImagePath, newTargetPath);
                    if (success)
                    {
                        Log.Message($"成功替换图片内容: {targetPath} (使用landi.png的内容，保持原文件名: {targetFileName})");
                    }
                }
            }
            else
            {
                Log.Warning($"源图片不存在: {sourceImagePath}");
                Log.Message("请确保landi.png文件存在于模组目录中");
            }
            
            Log.Message(ModRootPath);
            Log.Message(RimWorldModsPath);
        }

        /// <summary>
        /// 获取指定路径下所有2D图像资源的绝对路径
        /// </summary>
        /// <param name="rootPath">要搜索的根目录绝对路径</param>
        /// <param name="searchSubdirectories">是否搜索子目录，默认为true</param>
        /// <returns>包含所有图像文件绝对路径的字符串集合</returns>
        public static List<string> GetImagePaths(string rootPath, bool searchSubdirectories = true)
        {
            List<string> imagePaths = new List<string>();
            
            // 检查路径是否存在
            if (!Directory.Exists(rootPath))
            {
                Log.Warning($"路径不存在: {rootPath}");
                return imagePaths;
            }

            try
            {
                // 定义支持的图像文件扩展名
                string[] imageExtensions = { ".png", ".jpg", ".jpeg", ".bmp", ".tga", ".dds" };
                
                // 获取搜索选项
                SearchOption searchOption = searchSubdirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
                
                // 遍历所有文件
                foreach (string filePath in Directory.GetFiles(rootPath, "*.*", searchOption))
                {
                    // 获取文件扩展名并转换为小写进行比较
                    string extension = Path.GetExtension(filePath).ToLowerInvariant();
                    
                    // 检查是否为支持的图像文件
                    if (imageExtensions.Contains(extension))
                    {
                        // 将文件路径转换为绝对路径并添加到集合中
                        string absolutePath = Path.GetFullPath(filePath);
                        imagePaths.Add(absolutePath);
                    }
                }
                
                Log.Message($"在路径 {rootPath} 中找到 {imagePaths.Count} 个图像文件");
            }
            catch (Exception ex)
            {
                Log.Error($"搜索图像文件时发生错误: {ex.Message}");
            }
            
            return imagePaths;
        }

        /// <summary>
        /// 从绝对路径中获取文件名（包含扩展名）
        /// </summary>
        /// <param name="absolutePath">文件的绝对路径</param>
        /// <returns>文件名（包含扩展名），如果路径无效则返回空字符串</returns>
        public static string GetFileNameFromPath(string absolutePath)
        {
            try
            {
                // 检查路径是否为空或null
                if (string.IsNullOrEmpty(absolutePath))
                {
                    Log.Warning("提供的路径为空或null");
                    return string.Empty;
                }

                // 使用Path.GetFileName获取文件名（包含扩展名）
                string fileName = Path.GetFileName(absolutePath);
                
                // 如果获取的文件名为空，说明路径可能无效
                if (string.IsNullOrEmpty(fileName))
                {
                    Log.Warning($"无法从路径中提取文件名: {absolutePath}");
                    return string.Empty;
                }

                return fileName;
            }
            catch (Exception ex)
            {
                Log.Error($"获取文件名时发生错误: {ex.Message}");
                return string.Empty;
            }
        }

        /// <summary>
        /// 复制图片文件到指定路径并重命名
        /// </summary>
        /// <param name="sourceImagePath">源图片的绝对路径</param>
        /// <param name="targetImagePath">目标图片的绝对路径（包含新的文件名）</param>
        /// <returns>操作是否成功</returns>
        public static bool CopyAndRenameImage(string sourceImagePath, string targetImagePath)
        {
            try
            {
                // 检查源图片路径是否为空或null
                if (string.IsNullOrEmpty(sourceImagePath))
                {
                    Log.Warning("源图片路径为空或null");
                    return false;
                }

                // 检查目标图片路径是否为空或null
                if (string.IsNullOrEmpty(targetImagePath))
                {
                    Log.Warning("目标图片路径为空或null");
                    return false;
                }

                // 检查源图片文件是否存在
                if (!File.Exists(sourceImagePath))
                {
                    Log.Warning($"源图片文件不存在: {sourceImagePath}");
                    return false;
                }

                // 检查源文件是否为图片文件
                string sourceExtension = Path.GetExtension(sourceImagePath).ToLowerInvariant();
                string[] imageExtensions = { ".png", ".jpg", ".jpeg", ".bmp", ".tga", ".dds" };
                if (!imageExtensions.Contains(sourceExtension))
                {
                    Log.Warning($"源文件不是支持的图片格式: {sourceImagePath}");
                    return false;
                }

                // 获取目标目录路径
                string targetDirectory = Path.GetDirectoryName(targetImagePath);
                
                // 检查目标目录是否存在，如果不存在则创建
                if (!Directory.Exists(targetDirectory))
                {
                    try
                    {
                        Directory.CreateDirectory(targetDirectory);
                        Log.Message($"创建目标目录: {targetDirectory}");
                    }
                    catch (Exception ex)
                    {
                        Log.Error($"创建目标目录失败: {ex.Message}");
                        return false;
                    }
                }

                // 检查目标文件是否已存在，如果存在则删除
                if (File.Exists(targetImagePath))
                {
                    try
                    {
                        File.Delete(targetImagePath);
                        Log.Message($"删除已存在的目标文件: {targetImagePath}");
                    }
                    catch (Exception ex)
                    {
                        Log.Error($"删除已存在的目标文件失败: {ex.Message}");
                        return false;
                    }
                }

                // 复制文件到目标路径
                File.Copy(sourceImagePath, targetImagePath);
                
                // 验证复制是否成功
                if (File.Exists(targetImagePath))
                {
                    Log.Message($"成功复制图片: {sourceImagePath} -> {targetImagePath}");
                    return true;
                }
                else
                {
                    Log.Error("文件复制后目标文件不存在");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Log.Error($"复制图片时发生错误: {ex.Message}");
                return false;
            }
        }
    }
}
