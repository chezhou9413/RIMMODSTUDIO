using Verse;

namespace NarrativeRandyEnhanced
{
    /// <summary>
    /// 叙事者兰迪增强模组的主类
    /// </summary>
    public class NarrativeRandyEnhancedMod : Mod
    {
        /// <summary>
        /// 模组构造函数
        /// </summary>
        public NarrativeRandyEnhancedMod(ModContentPack content) : base(content)
        {
            Class1.OutputPathsOnGameStart();
        }
    }
} 